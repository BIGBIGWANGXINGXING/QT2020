<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en" sourcelanguage="zh">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="20"/>
        <location filename="mainwindow.cpp" line="40"/>
        <source>李恩惠189050616</source>
        <translation>GRH189050616</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="56"/>
        <source>均值滤波</source>
        <translation>Mean filtering</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="63"/>
        <source>边缘检测</source>
        <translation type="unfinished">Edge detection</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="70"/>
        <source>添加水印</source>
        <translation>Add watermark</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="77"/>
        <source>灰度化</source>
        <translation>Graying</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="84"/>
        <source>复合运算</source>
        <translation>Compound operation</translation>
    </message>
    <message>
        <source>英文</source>
        <translation type="vanished">English</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="205"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="258"/>
        <source>打开图片(&amp;I)</source>
        <translation type="unfinished">Open picture</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="265"/>
        <source>国际化</source>
        <translation type="unfinished">Internationalization</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="291"/>
        <source>open(&amp;M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="300"/>
        <source>new(&amp;N)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="310"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="45"/>
        <source>工具箱</source>
        <translation type="unfinished">Tool chest</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="305"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="67"/>
        <source>新增(&amp;N)</source>
        <translation type="unfinished">New(&amp;N)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="68"/>
        <source>编辑(&amp;E)</source>
        <translation type="unfinished">Edit(&amp;E)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="71"/>
        <source>保存(&amp;S)</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="93"/>
        <source>Save Image</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="93"/>
        <source>Images (*.png *.bmp *.jpg)</source>
        <translation></translation>
    </message>
</context>
</TS>
