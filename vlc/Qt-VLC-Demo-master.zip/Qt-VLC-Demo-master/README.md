# Qt-VLC-Demo
Use vlc-qt in Qt. It includes Video framing, draw on video and convert  framing image YUV to RGB by opencv.

# My blog
https://zhuanlan.zhihu.com/p/74190731

https://blog.csdn.net/m0_38133212/article/details/96289358
